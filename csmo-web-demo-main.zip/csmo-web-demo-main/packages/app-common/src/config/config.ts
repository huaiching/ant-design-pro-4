export const config = {
  mergedEnvConfig: false,
  basePath: {
    baseApi: 'https://dxp-cms-hrm-gateway-mli-qaa01.dev.aws06.mlic.cloud'
  },
  keyCloakConfig: {
    clientId: 'cms-core',
    realm: 'MLIInternalRealm',
    url: 'https://sso.core-uat.csmo.mli.com.corp'
  },
  microApps: [
    {
      name: 'app-micro',
      microApp: 'app-micro',
      appName: 'micro',
      envVariableName: 'MICRO',
      title: '微前端',
      entry: '//localhost:7001',
      icon: 'icon-personnel',
      path: '/container/micro'
    }
  ]
}

export const mergekeyCloakConfig = (configRequest: {
  CMS_KEYCLOAK_CONFIG_CLIENTID: string
  KEYCLOAK_REALM: string
  MLI_KEYCLOAK_APP_URL: string
}) => {
  config.keyCloakConfig = {
    clientId: configRequest.CMS_KEYCLOAK_CONFIG_CLIENTID ?? config.keyCloakConfig.clientId,
    realm: configRequest.KEYCLOAK_REALM ?? config.keyCloakConfig.realm,
    url: (configRequest.MLI_KEYCLOAK_APP_URL ?? config.keyCloakConfig.url) + '/auth/'
  }
}
