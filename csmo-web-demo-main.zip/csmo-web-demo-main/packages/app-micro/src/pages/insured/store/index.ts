import { createContext, useContext } from 'react'
import InsuredEntity from './store'

const storeContext = createContext(new InsuredEntity())

const useStores = () => useContext(storeContext)

export default useStores
