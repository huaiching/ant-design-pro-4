import { action, makeObservable, observable } from 'mobx'
import { v4 as uuid } from 'uuid'

export default class InsuredEntity {
  @observable insuredList: any[] = [
    {
      policyHandle: {
        id: '59dfad22-7af4-47dc-9c9f-93411f4b2043',
        name: '張三',
        birthday: '2024-04-10T00:00:00.000Z',
        gender: '男',
        insuranceYear: 2,
        idCard: 'A198514438',
        insured: 'dell lee',
        address: {
          sameAs: false,
          country: 'CN',
          county: '臺北市(A)',
          zipCode: '296900',
          city: '臺北市(A)',
          address: '三元路 1號',
          areaCode: '123',
          telephone: '081',
          extension: '12122112'
        },
        chargeAddress: {
          sameAs: true,
          country: 'CN',
          county: '臺北市(A)',
          zipCode: '296900',
          city: '臺北市(A)',
          address: '三元路 1號',
          areaCode: '123',
          telephone: '081',
          extension: '12345'
        },
        serviceCompany: {
          name: '三商美邦',
          jobContent: '保險理賠',
          occupationCode: '00010',
          level: '1',
          partTimeCode: '100010',
          partTimeLevel: '00020'
        },
        telephone: {
          idd: '1221',
          phoneNumber: '5588'
        },
        email: {
          sameAs: true,
          email: '351125847@qq.com'
        },
        form: {
          serialNumber: '025-5455454'
        }
      },
      info: {
        id: '59dfad22-7af4-47dc-9c9f-93411f4b2043',
        name: 'dell zhang',
        birthday: '2000-04-10T00:00:00.000Z',
        gender: '男',
        insuranceYear: 2,
        idCard: 'A171317720',
        insured: 'dell zhang',
        address: {
          sameAs: true,
          country: 'CN',
          county: '基隆市(C)',
          zipCode: '296900',
          city: '屏東縣(A)',
          address: '蓮花路21號',
          areaCode: '5822',
          telephone: '081',
          extension: '12211212'
        },
        chargeAddress: {
          sameAs: false,
          country: 'CN',
          county: '基隆市(C)',
          zipCode: '296900',
          city: '屏東縣(A)',
          address: '蓮花路21號',
          areaCode: '5822',
          telephone: '081',
          extension: '12211212'
        },
        telephone: {
          idd: '',
          phoneNumber: ''
        },
        email: {
          email: '25841624@qq.com'
        },
        serviceCompany: {
          name: '三商美邦',
          jobContent: '保險理賠',
          occupationCode: '00010',
          level: '1',
          partTimeCode: '100010',
          partTimeLevel: '00020'
        },
        form: {
          serialNumber: 'O14556455'
        }
      }
    },
    {
      policyHandle: {
        id: 'cbe490c5-ad5e-4414-b6fb-f7a8cad181d2',
        name: '李四',
        birthday: '1998-04-10T00:00:00.000Z',
        gender: '女',
        insuranceYear: 3,
        idCard: 'A122149061',
        insured: 'mark lie'
      },
      info: {
        id: '7911c8ae-150c-4991-ae3e-78d861ec555f',
        name: 'james lee',
        birthday: '1978-04-10T00:00:00.000Z',
        gender: '女',
        insuranceYear: 3,
        idCard: 'A191408035',
        insured: 'james lin'
      }
    },
    {
      policyHandle: {
        id: 'c4a5a49a-7ed2-4853-9cca-4b90166f53d4',
        name: '王五',
        birthday: '1988-04-10T00:00:00.000Z',
        gender: '男',
        insuranceYear: 4,
        idCard: 'A190315773',
        insured: 'Davie lee'
      },
      info: {
        id: 'c6df0d37-183f-4be3-a945-ea95031b07c9',
        name: 'mark wang',
        birthday: '1976-04-10T00:00:00.000Z',
        gender: '女',
        insuranceYear: 3,
        idCard: 'A191408035',
        insured: 'mark wang'
      }
    }
  ]

  constructor() {
    makeObservable(this)
  }

  @action
  setInsuredList(list: any) {
    this.insuredList = list
  }

  @action
  async getInsuredList() {
    return this.insuredList
  }
  @action
  delInsured(insuredId: string) {
    const insuredList = this.insuredList.filter((item) => item.policyHandle.id !== insuredId)
    this.setInsuredList(insuredList)
  }

  @action
  addInsured(params: any, id: string) {
    if (id) {
      const insuredList = this.insuredList?.filter((item) => item.policyHandle.id !== id)
      console.log('insuredList', insuredList)
      this.setInsuredList([
        ...insuredList,
        {
          ...params,
          policyHandle: {
            ...params.policyHandle,
            id
          }
        }
      ])
    } else {
      this.insuredList.push({
        ...params,
        policyHandle: {
          ...params.policyHandle,
          id: uuid()
        },
        info: {
          ...params.info,
          id: uuid()
        }
      })
      this.setInsuredList(this.insuredList)
    }
  }
}
