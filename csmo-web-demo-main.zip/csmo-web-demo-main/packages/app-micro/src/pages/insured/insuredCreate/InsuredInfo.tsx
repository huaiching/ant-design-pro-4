import {
  MliFormDatePicker,
  MliFormRow,
  MliFormSelect,
  MliFormSwitch,
  MliFormText
} from '@mli-csmo/base'
import { Card, Col, Row, Space } from 'antd'
import React, { useRef } from 'react'
import { useIntl } from 'umi'

const InsuredInfo: React.FC<any> = ({ show }) => {
  const { formatMessage } = useIntl()

  return (
    <Space direction="vertical" style={{ display: show ? 'flow' : 'none' }}>
      <Card title={formatMessage({ id: 'insured.insured.policyHandle' })}>
        <MliFormRow>
          <MliFormText moduleName="insured.insured" columnName="policyHandle.name" required />
          <MliFormDatePicker moduleName="insured.insured" columnName="policyHandle.birthday" />
          <MliFormText moduleName="insured.insured" columnName="policyHandle.gender" />
          <MliFormText moduleName="insured.insured" columnName="policyHandle.insuranceYear" />
          <MliFormText moduleName="insured.insured" columnName="policyHandle.idCard" />
          <MliFormSelect moduleName="insured.insured" columnName="policyHandle.insured" />
          <MliFormSelect moduleName="insured.insured" columnName="policyHandle.marital" />
        </MliFormRow>
        <Space direction="vertical">
          <Card
            type="inner"
            title={formatMessage({ id: 'insured.insured.policyHandle.title.address' })}
          >
            <MliFormRow>
              <MliFormSwitch
                moduleName="insured.insured"
                columnName="policyHandle.address.sameAs"
              />
            </MliFormRow>
            <MliFormRow>
              <MliFormText moduleName="insured.insured" columnName="policyHandle.address.country" />
              <MliFormText moduleName="insured.insured" columnName="policyHandle.address.zipCode" />
            </MliFormRow>
            <MliFormRow>
              <MliFormText moduleName="insured.insured" columnName="policyHandle.address.county" />
              <MliFormText moduleName="insured.insured" columnName="policyHandle.address.city" />
              <MliFormText
                colSize={2}
                moduleName="insured.insured"
                columnName="policyHandle.address.address"
              />
            </MliFormRow>
            <MliFormRow>
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.address.areaCode"
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.address.telephone"
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.address.extension"
              />
            </MliFormRow>
          </Card>
          <Card
            type="inner"
            title={formatMessage({ id: 'insured.insured.policyHandle.title.chargeAddress' })}
          >
            <MliFormRow>
              <MliFormSwitch
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.sameAs"
              />
            </MliFormRow>
            <MliFormRow>
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.country"
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.zipCode"
              />
            </MliFormRow>
            <MliFormRow>
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.county"
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.city"
              />
              <MliFormText
                colSize={2}
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.address"
              />
            </MliFormRow>
            <MliFormRow>
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.areaCode"
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.telephone"
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.chargeAddress.extension"
              />
            </MliFormRow>
          </Card>
          <Row gutter={8}>
            <Col span={12}>
              <Card
                type="inner"
                title={formatMessage({ id: 'insured.insured.policyHandle.title.email' })}
              >
                <MliFormRow>
                  <MliFormText
                    moduleName="insured.insured"
                    columnName="policyHandle.email.email"
                    colSize={4}
                  />
                </MliFormRow>
              </Card>
            </Col>
            <Col span={12}>
              <Card
                type="inner"
                title={formatMessage({ id: 'insured.insured.policyHandle.title.telephone' })}
              >
                <MliFormRow>
                  <MliFormText
                    moduleName="insured.insured"
                    columnName="policyHandle.telephone.idd"
                  />
                  <MliFormText
                    moduleName="insured.insured"
                    columnName="policyHandle.telephone.phoneNumber"
                    colSize={2}
                  />
                </MliFormRow>
              </Card>
            </Col>
          </Row>
          <Card
            type="inner"
            title={formatMessage({ id: 'insured.insured.policyHandle.title.serviceCompany' })}
          >
            <MliFormRow>
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.serviceCompany.name"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.serviceCompany.jobContent"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.serviceCompany.occupationCode"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.serviceCompany.level"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.serviceCompany.partTimeCode"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="policyHandle.serviceCompany.partTimeLevel"
                colSize={4 / 3}
              />
            </MliFormRow>
          </Card>
          <Card>
            <MliFormText
              moduleName="insured.insured"
              columnName="policyHandle.form.serialNumber"
              colSize={4 / 3}
            />
          </Card>
        </Space>
      </Card>
      <Card title={formatMessage({ id: 'insured.insured.info' })}>
        <MliFormRow>
          <MliFormText moduleName="insured.insured" columnName="info.name" required />
          <MliFormDatePicker moduleName="insured.insured" columnName="info.birthday" />
          <MliFormText moduleName="insured.insured" columnName="info.gender" />
          <MliFormText moduleName="insured.insured" columnName="info.insuranceYear" />
          <MliFormText moduleName="insured.insured" columnName="info.idCard" />
          <MliFormSelect moduleName="insured.insured" columnName="info.insured" />
          <MliFormSelect moduleName="insured.insured" columnName="info.marital" />
        </MliFormRow>
        <Space direction="vertical">
          <Card type="inner" title={formatMessage({ id: 'insured.insured.info.title.address' })}>
            <MliFormRow>
              <MliFormSwitch moduleName="insured.insured" columnName="info.address.sameAs" />
            </MliFormRow>
            <MliFormRow>
              <MliFormText moduleName="insured.insured" columnName="info.address.country" />
              <MliFormText moduleName="insured.insured" columnName="info.address.zipCode" />
            </MliFormRow>
            <MliFormRow>
              <MliFormText moduleName="insured.insured" columnName="info.address.county" />
              <MliFormText moduleName="insured.insured" columnName="info.address.city" />
              <MliFormText
                colSize={2}
                moduleName="insured.insured"
                columnName="info.address.address"
              />
            </MliFormRow>
            <MliFormRow>
              <MliFormText moduleName="insured.insured" columnName="info.address.areaCode" />
              <MliFormText moduleName="insured.insured" columnName="info.address.telephone" />
              <MliFormText moduleName="insured.insured" columnName="info.address.extension" />
            </MliFormRow>
          </Card>
          <Card
            type="inner"
            title={formatMessage({ id: 'insured.insured.info.title.chargeAddress' })}
          >
            <MliFormRow>
              <MliFormSwitch moduleName="insured.insured" columnName="info.chargeAddress.sameAs" />
            </MliFormRow>
            <MliFormRow>
              <MliFormText moduleName="insured.insured" columnName="info.chargeAddress.country" />
              <MliFormText moduleName="insured.insured" columnName="info.chargeAddress.zipCode" />
            </MliFormRow>
            <MliFormRow>
              <MliFormText moduleName="insured.insured" columnName="info.chargeAddress.county" />
              <MliFormText moduleName="insured.insured" columnName="info.chargeAddress.city" />
              <MliFormText
                colSize={2}
                moduleName="insured.insured"
                columnName="info.chargeAddress.address"
              />
            </MliFormRow>
            <MliFormRow>
              <MliFormText moduleName="insured.insured" columnName="info.chargeAddress.areaCode" />
              <MliFormText moduleName="insured.insured" columnName="info.chargeAddress.telephone" />
              <MliFormText moduleName="insured.insured" columnName="info.chargeAddress.extension" />
            </MliFormRow>
          </Card>
          <Row gutter={8}>
            <Col span={12}>
              <Card type="inner" title={formatMessage({ id: 'insured.insured.info.title.email' })}>
                <MliFormRow>
                  <MliFormText
                    moduleName="insured.insured"
                    columnName="info.email.email"
                    colSize={4}
                  />
                </MliFormRow>
              </Card>
            </Col>
            <Col span={12}>
              <Card
                type="inner"
                title={formatMessage({ id: 'insured.insured.info.title.telephone' })}
              >
                <MliFormRow>
                  <MliFormText moduleName="insured.insured" columnName="info.telephone.idd" />
                  <MliFormText
                    moduleName="insured.insured"
                    columnName="info.telephone.phoneNumber"
                    colSize={2}
                  />
                </MliFormRow>
              </Card>
            </Col>
          </Row>
          <Card
            type="inner"
            title={formatMessage({ id: 'insured.insured.info.title.serviceCompany' })}
          >
            <MliFormRow>
              <MliFormText
                moduleName="insured.insured"
                columnName="info.serviceCompany.name"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="info.serviceCompany.jobContent"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="info.serviceCompany.occupationCode"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="info.serviceCompany.level"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="info.serviceCompany.partTimeCode"
                colSize={4 / 3}
              />
              <MliFormText
                moduleName="insured.insured"
                columnName="info.serviceCompany.partTimeLevel"
                colSize={4 / 3}
              />
            </MliFormRow>
          </Card>
          <Card>
            <MliFormText
              moduleName="insured.insured"
              columnName="info.form.serialNumber"
              colSize={4 / 3}
            />
          </Card>
        </Space>
      </Card>
    </Space>
  )
}

export default InsuredInfo
