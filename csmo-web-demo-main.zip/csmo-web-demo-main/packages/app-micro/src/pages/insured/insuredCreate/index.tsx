import { PageContainer, ProForm, ProFormInstance } from '@ant-design/pro-components'
import { Button } from 'antd'
import React, { useEffect, useRef, useState } from 'react'
import { useIntl, history, useParams } from 'umi'
import useStores from '../store'
import InsuredInfo from './InsuredInfo'
const Insured: React.FC = () => {
  const { formatMessage } = useIntl()
  const formRef = useRef<ProFormInstance>()
  const [activeTabKey, setActiveTabKey] = useState<string>('insured')
  const store = useStores()
  const params = useParams<{ id?: string; optionType?: string }>()

  useEffect(() => {
    if (params.id) {
      const insuredInfo = store.insuredList?.find(item => item.policyHandle.id === params.id)
      formRef.current?.setFieldsValue(insuredInfo)
    }
    
  }, [])

  return (
    <PageContainer
      header={{
        title: 'TP123456789',
        ghost: true,
        extra: [
          <Button key="cancel">{formatMessage({ id: 'common.button.cancel' })}</Button>,
          <Button
            key="temp-save"
            onClick={async () => {
              const data = await formRef.current?.getFieldsValue()
              await store.addInsured(data, params.id)
              history.push({
                pathname: '/insured'
              })
            }}
          >
            {formatMessage({ id: 'common.button.temp.save' })}
          </Button>,
          <Button
            type="primary"
            key="save"
          >
            {formatMessage({ id: 'common.button.save' })}
          </Button>
        ]
      }}
      tabList={[
        {
          key: 'insured',
          tab: formatMessage({ id: 'insured.tab.insured' }),
          closable: false
        },
        {
          key: 'beneficiaries',
          tab: formatMessage({ id: 'insured.tab.beneficiaries' }),
          closable: false
        },
        {
          key: 'indemnify',
          tab: formatMessage({ id: 'insured.tab.indemnify' }),
          closable: false
        },
        {
          key: 'other',
          tab: formatMessage({ id: 'insured.tab.other' }),
          closable: false
        },
        {
          key: 'notice',
          tab: formatMessage({ id: 'insured.tab.notice' }),
          closable: false
        },
        {
          key: 'agent',
          tab: formatMessage({ id: 'insured.tab.agent' }),
          closable: false
        }
      ]}
      tabActiveKey={activeTabKey}
      onTabChange={setActiveTabKey}
      tabProps={{
        type: 'editable-card',
        hideAdd: true
      }}
    >
      <ProForm formRef={formRef} grid labelWrap submitter={false}>
        <InsuredInfo show={activeTabKey === 'insured'} />
      </ProForm>
    </PageContainer>
  )
}

export default Insured
