import { ActionType, PageContainer } from '@ant-design/pro-components'
import { filterUsefulParams, MliTable } from '@mli-csmo/base'
import { Button, Popconfirm, Tooltip } from 'antd'
import dayjs from 'dayjs'
import React, { useRef, useState } from 'react'
import { history, useIntl } from 'umi'
import useStores from '../store'

const Insured: React.FC = () => {
  const { formatMessage } = useIntl()
  const ref = useRef<ActionType>()
  const [activeTabKey, setActiveTabKey] = useState<string>('insured')
  const insured = 'insured.insured'
  const store = useStores()
  const handleAddInsured = (id?: string) => {
    history.push({
      pathname: id ? `/insured/edit/${id}` : '/insured/add'
    })
  }

  const handleDelInsured = async (id: string) => {
    await store.delInsured(id)
  }

  const columns: any[] = [
    {
      moduleName: insured,
      columnName: 'policyHandle.name',
      fieldProps: {
        maxLength: 5
      }
    },
    {
      moduleName: insured,
      columnName: 'policyHandle.birthday',
      valueType: 'text',
      render: (_: any, record: any) => {
        return dayjs(record.policyHandle.birthday).format('TTT/MM/DD')
      }
    },
    {
      moduleName: insured,
      columnName: 'policyHandle.gender',
      valueType: 'select',
      fieldProps: {
        options: [
          { code: 'male', value: '男' },
          { code: 'female', value: '女' }
        ]
      }
    },
    {
      moduleName: insured,
      columnName: 'policyHandle.insuranceYear',
      valueType: 'text'
    },
    {
      moduleName: insured,
      columnName: 'policyHandle.idCard',
      valueType: 'text'
    },
    {
      moduleName: insured,
      columnName: 'policyHandle.insured',
      valueType: 'text',
      search: false
    },
    {
      title: formatMessage({
        id: 'common.table.header.action'
      }),
      dataIndex: 'option',
      fixed: 'right',
      valueType: 'option',
      width: 140,
      render: (_, record) => {
        return (
          <>
            <Button type="link" onClick={() => handleAddInsured(record.policyHandle.id)}>
              <i className="iconfont icon-edit-profile" />
            </Button>

            <Popconfirm
              key="delete"
              placement="top"
              title={formatMessage({
                id: 'common.confirm.remove.title'
              })}
              onConfirm={async () => {
                await handleDelInsured(record.policyHandle.id)
                ref.current?.reload()
              }}
              okText={formatMessage({
                id: 'common.confirm.btn.ok'
              })}
              cancelText={formatMessage({
                id: 'common.confirm.btn.cancel'
              })}
            >
              <Tooltip
                title={formatMessage({
                  id: 'common.button.remove'
                })}
              >
                <Button type="link">
                  <i className="iconfont icon-delete" />
                </Button>
              </Tooltip>
            </Popconfirm>
          </>
        )
      }
    }
  ]

  const searchParamsTransform = (params: any): any => {
    const newParam = {
      ...params
    }

    return filterUsefulParams({
      compoundOperator: 'AND',
      nested: [
        {
          field: 'policyHandle.name',
          queryOperator: 'LIKE',
          value: newParam?.policyHandle.name
        },
        {
          field: 'policyHandle.birthday',
          queryOperator: 'LIKE',
          value: newParam?.policyHandle.birthday
        },
        {
          field: 'policyHandle.gender',
          queryOperator: 'EQ',
          value: newParam?.policyHandle.gender
        },
        {
          field: 'policyHandle.insuranceYear',
          queryOperator: 'LIKE',
          value: newParam?.policyHandle.insuranceYear
        },
        {
          field: 'policyHandle.idCard',
          queryOperator: 'LIKE',
          value: newParam?.policyHandle.idCard
        }
      ],
      sorts: [{ field: 'accessTrackInfo.updatedOn', direction: 'desc' }]
    })
  }

  return (
    <PageContainer
      header={{
        title: '查詢頁面模板',
        ghost: true
      }}
      tabActiveKey={activeTabKey}
      onTabChange={setActiveTabKey}
      tabProps={{
        type: 'editable-card',
        hideAdd: true
      }}
    >
      <MliTable
        moduleName="insured-entity"
        scroll={{ x: 'max-content' }}
        searchParamsTransform={searchParamsTransform}
        columns={columns}
        cardBordered
        request={async () => {
          const insuredList = await store.getInsuredList()
          return {
            data: insuredList,
            success: true,
            total: insuredList.length
          }
        }}
        rowKey="id"
        toolBarRender={() => [
          <>
            <Button type="primary" onClick={() => handleAddInsured()}>
              {formatMessage({
                id: 'insured.beneficiaries.button.add'
              })}
            </Button>
          </>
        ]}
      />
    </PageContainer>
  )
}

export default Insured
