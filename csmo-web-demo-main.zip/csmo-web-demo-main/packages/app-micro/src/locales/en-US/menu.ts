export default {
  'menu.exception.403': '403',
  'menu.exception.404': '404',
  'menu.exception.500': '500',
  'menu.home': '首頁',
  'menu.insured': '受保人',

  'menu.reactDemo': 'React 基本語法範例',
  'menu.reactDemo.demo01': '頁面檔的基本結構',
  'menu.reactDemo.demo02': 'JS 與 TypeScript',
  'menu.reactDemo.demo02.demo02-01': 'CSS 樣式',
  'menu.reactDemo.demo02.demo02-02': '變數宣告 與 型態設定',
  'menu.reactDemo.demo02.demo02-03': '複雜型別(type)',  'menu.reactDemo.demo02.demo02-04': '介面(interface)',
  'menu.reactDemo.demo02.demo02-05': '陣列',
  'menu.reactDemo.demo02.demo02-06': '函式',
  'menu.reactDemo.demo02.demo02-07': '多型別變數(聯集)',
  'menu.reactDemo.demo02.demo02-08': '多型別變數(交集)',
  'menu.reactDemo.demo02.demo02-09': 'JS 語句',
  'menu.reactDemo.demo02.demo02-10': '樣板字串',
  'menu.reactDemo.demo03': 'useState 狀態機',
  'menu.reactDemo.demo04': 'props 組件的信息傳遞',
  'menu.reactDemo.demo05': 'useReducer 管理複雜邏輯的狀態機',
  'menu.reactDemo.demo06': 'useContext 遠端的信息傳遞',
  'menu.reactDemo.demo07': 'useEffect 效果鉤子',
  'menu.reactDemo.demo08': 'useRef 從輸入框獲取值',

  'menu.antdDemo': 'Ant Design 元件範例',

  'menu.mobXDemo': 'Mobx 使用範例',
  'menu.mobXDemo.demo01': '使用說明',
  'menu.mobXDemo.demo02': '使用範例',
  'menu.mobXDemo.demo03': 'formRef 使用範例'
}
