import home from './en-US/home'
import menu from './en-US/menu'
import insured from './en-US/insured'
import insuantdDemored from './zh-TW/antdDemo'
import { commonLocales } from '@mli-csmo/app-common/src/util/locales/en-US'


export default {
  'micro.app.miro.title': 'miro title1',
  ...commonLocales,
  ...menu,
  ...insured,
    ...insuantdDemored,
  ...home
}
