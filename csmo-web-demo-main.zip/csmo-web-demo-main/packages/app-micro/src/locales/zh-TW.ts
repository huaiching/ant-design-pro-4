import home from './zh-TW/home'
import menu from './zh-TW/menu'
import insured from './zh-TW/insured'
import insuantdDemored from './zh-TW/antdDemo'
import { commonLocales } from '@mli-csmo/app-common/src/util/locales/zh-TW'

export default {
  'micro.app.miro.title': '子應用',
  ...commonLocales,
  ...menu,
  ...insured,
  ...insuantdDemored,
  ...home
}
